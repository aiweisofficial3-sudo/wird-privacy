/* Wird – Android bridge: schedules real prayer alarms (work with the app closed). Only active inside the Android app. */
(function(){
var C=window.Capacitor;
if(!C||!C.isNativePlatform||!C.isNativePlatform())return;
var LN=C.Plugins&&C.Plugins.LocalNotifications;
if(!LN)return;
var KEYS=["fajr","dhuhr","asr","maghrib","isha"],DAYS=7,timer=0,asked=0,chDone=0;
/* the system plays the sound now, so the in-page alert would double it */
try{window.ptAlert=function(){}}catch(e){}
function lang(){var l=(location.hash.slice(1).split("-")[0]);if(!L[l])l=store("lang")||"en";if(!L[l])l="en";return l}
function chans(){
if(chDone)return Promise.resolve();chDone=1;
var d=[
{id:"wird_s",name:"Wird – silent",importance:2,vibration:false,visibility:1},
{id:"wird_v",name:"Wird – vibration",importance:4,vibration:true,visibility:1},
{id:"wird_t",name:"Wird – soft tone",importance:4,sound:"chime.mp3",vibration:false,visibility:1},
{id:"wird_a",name:"Wird – adhan",importance:5,sound:"adhan.mp3",vibration:true,visibility:1}];
return Promise.all(d.map(function(x){return LN.createChannel(x).catch(function(){})}))}
function perms(){
return LN.checkPermissions().then(function(p){
if(p.display==="granted")return true;
if(asked)return false;asked=1;
return LN.requestPermissions().then(function(r){return r.display==="granted"})}).catch(function(){return false})}
function exact(){
return LN.checkExactNotificationSetting().then(function(s){
if(s&&s.exact_alarm==="denied"&&!exact._a){exact._a=1;return LN.changeExactNotificationSetting().catch(function(){})}}).catch(function(){})}
function build(){
var c=ptCfg(),any=false,k,now=Date.now(),t=T[lang()].pt,list=[],i,j,id=1000;
for(k in c.rem)if(c.rem[k])any=true;
if(!any)return list;
for(i=0;i<DAYS;i++){
var day=ptDay(c,now+i*86400000);
for(j=0;j<KEYS.length;j++){
k=KEYS[j];if(!c.rem[k]||isNaN(day.t[k]))continue;
var at=day.t[k]-c.lead*60000;
if(at<=now+5000)continue;
var lv=(c.lv&&c.lv[k])||"s",ch=lv==="a"?"wird_a":lv==="t"?"wird_t":lv==="v"?"wird_v":"wird_s";
list.push({id:id+i*10+j,title:c.lead?t[k]+" "+t.soonin+" "+c.lead+" "+t.mins:t.notif+" "+t[k],body:"وِرْد · Wird",channelId:ch,schedule:{at:new Date(at),allowWhileIdle:true},smallIcon:"ic_stat_wird"})}}
return list}
function resched(){
chans().then(function(){return LN.getPending()}).then(function(p){
var ids=(p&&p.notifications||[]).map(function(n){return{id:n.id}});
return ids.length?LN.cancel({notifications:ids}):0}).then(function(){
var list=build();if(!list.length)return;
return perms().then(function(ok){if(!ok)return;return exact().then(function(){return LN.schedule({notifications:list})})})}).catch(function(){})}
function later(){clearTimeout(timer);timer=setTimeout(resched,800)}
document.addEventListener("change",later,true);
document.addEventListener("click",function(e){if(e.target&&e.target.id==="pperm")later()},true);
document.addEventListener("visibilitychange",function(){if(!document.hidden)later()});
window.addEventListener("load",later);
setTimeout(later,2500);
})();

/* Wird – asks Google Play whether a newer version exists; the page shows the update bell only when it does. Never throws. */
(function(){
try{
var C=window.Capacitor;
if(!C||!C.isNativePlatform||!C.isNativePlatform())return;
var last=0;
function call(m,o){
if(C.Plugins&&C.Plugins.AppUpdate&&C.Plugins.AppUpdate[m])return C.Plugins.AppUpdate[m](o||{});
if(C.nativePromise)return C.nativePromise("AppUpdate",m,o||{});
return Promise.reject(new Error("no plugin"))}
function check(){
last=Date.now();
try{
call("getAppUpdateInfo").then(function(i){
if(i&&i.updateAvailability===2){window.WIRD_UPD=i;try{window.dispatchEvent(new CustomEvent("wirdupdate"))}catch(e){}}
}).catch(function(){})}catch(e){}}
setTimeout(check,4000);
document.addEventListener("visibilitychange",function(){if(!document.hidden&&Date.now()-last>2*3600*1000)check()});
}catch(e){}
})();

/* Wird – shows a small note inside the prayer settings when Android blocks notifications or exact alarms (the usual reason an adhan arrives late or not at all). Never throws. */
(function(){
try{
var C=window.Capacitor;
if(!C||!C.isNativePlatform||!C.isNativePlatform())return;
var LN=C.Plugins&&C.Plugins.LocalNotifications;
if(!LN)return;
var W={
ar:{n:"الإشعارات مغلقة لهذا التطبيق، فلن يصلك الأذان. افتح إعدادات الهاتف ← التطبيقات ← وِرْد ← الإشعارات وفعّلها.",e:"إذن «المنبّهات والتذكيرات» مغلق، وقد يتأخر الأذان بضع دقائق. فعّله من إعدادات الهاتف ← التطبيقات ← وِرْد."},
de:{n:"Benachrichtigungen sind für diese App ausgeschaltet, daher kommt kein Adhan. Öffne Einstellungen ← Apps ← Wird ← Benachrichtigungen und schalte sie ein.",e:"Die Berechtigung „Wecker und Erinnerungen“ ist aus, der Adhan kann sich um einige Minuten verspäten. Aktiviere sie unter Einstellungen ← Apps ← Wird."},
en:{n:"Notifications are turned off for this app, so the adhan will not reach you. Open phone Settings ← Apps ← Wird ← Notifications and turn them on.",e:"The “Alarms & reminders” permission is off, so the adhan may arrive a few minutes late. Turn it on in phone Settings ← Apps ← Wird."},
ru:{n:"Уведомления для приложения выключены, поэтому азан не придёт. Откройте Настройки ← Приложения ← Wird ← Уведомления и включите их.",e:"Разрешение «Будильники и напоминания» выключено, азан может опаздывать на несколько минут. Включите его в Настройки ← Приложения ← Wird."}};
var busy=0;
function lg(){var l=location.hash.slice(1).split("-")[0];return W[l]?l:"en"}
function show(){
if(busy)return;var prm=document.getElementById("prm");if(!prm||!prm.parentNode)return;busy=1;
Promise.all([LN.checkPermissions().catch(function(){return null}),LN.checkExactNotificationSetting().catch(function(){return null})]).then(function(r){
busy=0;var sec=document.getElementById("prm");if(!sec||!sec.parentNode)return;
var w=W[lg()],txt=(r[0]&&r[0].display==="denied")?w.n:(r[1]&&r[1].exact_alarm==="denied")?w.e:"",el=document.getElementById("pwarn");
if(!txt){if(el&&el.parentNode)el.parentNode.removeChild(el);return}
if(!el){el=document.createElement("p");el.id="pwarn";el.className="note";el.setAttribute("role","status");el.style.cssText="font-weight:700;color:var(--accent-ink,#8a5a00);margin:8px 0";sec.parentNode.insertBefore(el,sec)}
el.textContent=txt}).catch(function(){busy=0})}
function soon(){setTimeout(show,350)}
window.addEventListener("hashchange",soon);
document.addEventListener("visibilitychange",function(){if(!document.hidden)soon()});
window.addEventListener("load",soon);
setTimeout(show,1800);
}catch(e){}
})();
