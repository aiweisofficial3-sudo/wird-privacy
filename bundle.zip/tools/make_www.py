# Builds www/ from the web app folder (../pwa): adds the Android bridge, drops the service worker (not needed inside the app)
import shutil,os,re,sys
src=sys.argv[1] if len(sys.argv)>1 else '../pwa'
here=os.path.dirname(os.path.abspath(__file__)); root=os.path.dirname(here)
www=os.path.join(root,'www'); src=os.path.abspath(os.path.join(root,src)) if not os.path.isabs(src) else src
if os.path.exists(www): shutil.rmtree(www)
shutil.copytree(src,www,ignore=shutil.ignore_patterns('sw.js'))
h=open(www+'/index.html',encoding='utf-8').read()
h2=re.sub(r'<script>if\("serviceWorker"in navigator.*?</script>\n?','',h,flags=re.S)
assert h2!=h,'service worker block not found'
assert h2.count('</body>')==1
h2=h2.replace('</body>','<script src="native.js"></script>\n</body>')
open(www+'/index.html','w',encoding='utf-8').write(h2)
shutil.copy(os.path.join(root,'native','native.js'),www+'/native.js')
print('www ok',len(h2))
