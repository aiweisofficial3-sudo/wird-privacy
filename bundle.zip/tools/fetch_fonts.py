# Downloads the 604 QCF v2 page fonts into www/mushaf/f/ and points www/mushaf/fonts.css at them, so the Madinah Mushaf works with no internet.
# Runs in the GitHub build (the build machine has internet). Fonts that fail to download keep their online address (online fallback), nothing else changes.
import sys,os,re,hashlib,time,urllib.request
mu=sys.argv[1] if len(sys.argv)>1 else 'www/mushaf'
base=os.environ.get('FONT_BASE','https://verses.quran.foundation/fonts/quran/hafs/v2/woff2/')+'p%d.woff2'
out=os.path.join(mu,'f');os.makedirs(out,exist_ok=True)
ok={};total=0;lines=[]
def get(n):
    for t in range(4):
        try:
            r=urllib.request.urlopen(urllib.request.Request(base%n,headers={'User-Agent':'Mozilla/5.0 (Wird build)'}),timeout=60).read()
            if r[:4]==b'wOF2' and len(r)>500:return r
        except Exception as e:err=e
        time.sleep(1.5*(t+1))
    return None
for n in range(1,605):
    d=get(n)
    if d is None:print('FAILED page',n);continue
    open(os.path.join(out,'p%d.woff2'%n),'wb').write(d);ok[n]=1;total+=len(d)
    lines.append('%s  p%d.woff2  %d'%(hashlib.sha256(d).hexdigest(),n,len(d)))
css=open(os.path.join(mu,'fonts.css'),encoding='utf-8').read()
def sub(m):
    n=int(m.group(1));return 'f/p%d.woff2'%n if n in ok else m.group(0)
css2=re.sub(r'https://verses\.quran\.foundation/fonts/quran/hafs/v2/woff2/p(\d+)\.woff2',sub,css)
open(os.path.join(mu,'fonts.css'),'w',encoding='utf-8').write(css2)
open(os.path.join(mu,'fonts.sha256'),'w').write('\n'.join(lines)+'\n')
print('fonts downloaded: %d of 604, total %.1f MB'%(len(ok),total/1048576))
if len(ok)<604:print('WARNING: some fonts stay online-only')
