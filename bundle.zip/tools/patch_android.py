# Run after "npx cap add android": sounds, icons, permissions, version, signing
import os,re,shutil,sys
from PIL import Image
root=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
a=os.path.join(root,'android','app')
res=os.path.join(a,'src','main','res')
# 1. sounds + status icon
os.makedirs(res+'/raw',exist_ok=True)
for f in os.listdir(root+'/native/res/raw'): shutil.copy(root+'/native/res/raw/'+f,res+'/raw/'+f)
os.makedirs(res+'/drawable',exist_ok=True)
shutil.copy(root+'/native/res/drawable/ic_stat_wird.xml',res+'/drawable/ic_stat_wird.xml')
# 2. launcher icons (legacy PNGs; remove adaptive xml so these are used)
src=Image.open(root+'/www/icons/icon-512.png').convert('RGBA')
sizes={'mdpi':48,'hdpi':72,'xhdpi':96,'xxhdpi':144,'xxxhdpi':192}
for d,s in sizes.items():
    p=res+'/mipmap-'+d
    os.makedirs(p,exist_ok=True)
    im=src.resize((s,s),Image.LANCZOS)
    for n in ('ic_launcher.png','ic_launcher_round.png','ic_launcher_foreground.png'): im.save(p+'/'+n)
shutil.rmtree(res+'/mipmap-anydpi-v26',ignore_errors=True)
# 3. permissions
mf=a+'/src/main/AndroidManifest.xml'
m=open(mf,encoding='utf-8').read()
add=''
for perm in ('VIBRATE','SCHEDULE_EXACT_ALARM','ACCESS_COARSE_LOCATION','ACCESS_FINE_LOCATION'):
    if 'android.permission.'+perm not in m: add+='    <uses-permission android:name="android.permission.%s"/>\n'%perm
if add: m=m.replace('</manifest>',add+'</manifest>')
assert 'SCHEDULE_EXACT_ALARM' in m
open(mf,'w',encoding='utf-8').write(m)
# 4. version + signing
bg=a+'/build.gradle'
g=open(bg,encoding='utf-8').read()
run=os.environ.get('GITHUB_RUN_NUMBER','1')
g,n=re.subn(r'versionCode\s+\d+','versionCode '+run,g); assert n==1
g,n=re.subn(r'versionName\s+"[^"]*"','versionName "1.0.'+run+'"',g); assert n==1
sign='''    signingConfigs {
        release {
            def kp = new Properties()
            kp.load(new FileInputStream(rootProject.file("../signing/keystore.properties")))
            storeFile file(kp['storeFile'])
            storePassword kp['storePassword']
            keyAlias kp['keyAlias']
            keyPassword kp['keyPassword']
        }
    }
'''
assert g.count('    buildTypes {')==1
g=g.replace('    buildTypes {',sign+'    buildTypes {')
assert g.count('        release {\n            minifyEnabled')==1
g=g.replace('        release {\n            minifyEnabled','        release {\n            signingConfig signingConfigs.release\n            minifyEnabled')
open(bg,'w',encoding='utf-8').write(g)
# 5. minSdk 24 (Play auto-protection requires >= 24)
vg=os.path.join(root,'android','variables.gradle')
v=open(vg,encoding='utf-8').read()
v,n=re.subn(r'minSdkVersion\s*=\s*\d+','minSdkVersion = 24',v); assert n==1
v,n=re.subn(r'compileSdkVersion\s*=\s*\d+','compileSdkVersion = 36',v); assert n==1
v,n=re.subn(r'targetSdkVersion\s*=\s*\d+','targetSdkVersion = 36',v); assert n==1
open(vg,'w',encoding='utf-8').write(v)
# 6. old Android Gradle Plugin: allow compileSdk 36 (warning only)
gp=os.path.join(root,'android','gradle.properties')
t=open(gp,encoding='utf-8').read()
if 'suppressUnsupportedCompileSdk' not in t: t+='\nandroid.suppressUnsupportedCompileSdk=36\n'
open(gp,'w',encoding='utf-8').write(t)
# 7. target 35+ draws edge-to-edge: keep the page clear of status/navigation bars and keyboard
ma=os.path.join(a,'src','main','java','app','wird','adhkar','MainActivity.java')
open(ma,'w',encoding='utf-8').write('''package app.wird.adhkar;

import android.content.ClipData;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Base64;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebView;
import androidx.activity.OnBackPressedCallback;
import androidx.core.content.FileProvider;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import com.getcapacitor.BridgeActivity;
import java.io.File;
import java.io.FileOutputStream;

public class MainActivity extends BridgeActivity {
    public class WirdJs {
        @JavascriptInterface
        public void shareText(final String text) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    try {
                        Intent i = new Intent(Intent.ACTION_SEND);
                        i.setType("text/plain");
                        i.putExtra(Intent.EXTRA_TEXT, text);
                        startActivity(Intent.createChooser(i, null));
                    } catch (Exception e) {
                    }
                }
            });
        }

        @JavascriptInterface
        public void shareImage(final String b64, final String name, final String text) {
            try {
                byte[] data = Base64.decode(b64, Base64.DEFAULT);
                File dir = new File(getCacheDir(), "share");
                dir.mkdirs();
                String safe = name.replaceAll("[^A-Za-z0-9._-]", "_");
                File f = new File(dir, safe);
                FileOutputStream o = new FileOutputStream(f);
                o.write(data);
                o.close();
                final Uri u = FileProvider.getUriForFile(MainActivity.this, getPackageName() + ".wirdshare", f);
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            Intent i = new Intent(Intent.ACTION_SEND);
                            i.setType("image/png");
                            i.putExtra(Intent.EXTRA_STREAM, u);
                            if (text != null && text.length() > 0) i.putExtra(Intent.EXTRA_TEXT, text);
                            i.setClipData(ClipData.newRawUri("", u));
                            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                            startActivity(Intent.createChooser(i, null));
                        } catch (Exception e) {
                        }
                    }
                });
            } catch (Exception e) {
            }
        }

        @JavascriptInterface
        public void exit() {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    finish();
                }
            });
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        View r = findViewById(android.R.id.content);
        if (r != null) ViewCompat.requestApplyInsets(r);
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        final View root = findViewById(android.R.id.content);
        final int initialLeft = root.getPaddingLeft();
        final int initialTop = root.getPaddingTop();
        final int initialRight = root.getPaddingRight();
        final int initialBottom = root.getPaddingBottom();
        final int handledTypes = WindowInsetsCompat.Type.systemBars()
                | WindowInsetsCompat.Type.displayCutout()
                | WindowInsetsCompat.Type.ime();
        ViewCompat.setOnApplyWindowInsetsListener(root, (v, w) -> {
            Insets s = w.getInsets(handledTypes);
            v.setPadding(initialLeft + s.left, initialTop + s.top,
                    initialRight + s.right, initialBottom + s.bottom);
            android.util.Log.d("WIRD_INSETS", "L=" + s.left + " T=" + s.top + " R=" + s.right + " B=" + s.bottom
                    + " navVisible=" + w.isVisible(WindowInsetsCompat.Type.navigationBars())
                    + " navIgnoringVisibilityB=" + w.getInsetsIgnoringVisibility(WindowInsetsCompat.Type.navigationBars()).bottom);
            if (android.os.Build.VERSION.SDK_INT >= 30) {
                try {
                    WindowInsetsCompat.Builder b = new WindowInsetsCompat.Builder(w);
                    try { b.setInsets(WindowInsetsCompat.Type.statusBars(), Insets.NONE); } catch (Exception ignored) {}
                    try { b.setInsets(WindowInsetsCompat.Type.navigationBars(), Insets.NONE); } catch (Exception ignored) {}
                    try { b.setInsets(WindowInsetsCompat.Type.captionBar(), Insets.NONE); } catch (Exception ignored) {}
                    try { b.setInsets(WindowInsetsCompat.Type.displayCutout(), Insets.NONE); } catch (Exception ignored) {}
                    try { b.setInsets(WindowInsetsCompat.Type.ime(), Insets.NONE); } catch (Exception ignored) {}
                    return b.build();
                } catch (Exception e) {
                }
            }
            return WindowInsetsCompat.CONSUMED;
        });
        root.post(new Runnable() {
            @Override
            public void run() {
                ViewCompat.requestApplyInsets(root);
            }
        });
        final WebView web = getBridge().getWebView();
        web.addJavascriptInterface(new WirdJs(), "WirdNative");
        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                final OnBackPressedCallback self = this;
                web.evaluateJavascript(
                        "(function(){try{return window.wirdBack?window.wirdBack():false}catch(e){return false}})()",
                        new ValueCallback<String>() {
                            @Override
                            public void onReceiveValue(String value) {
                                if (!"true".equals(value)) {
                                    self.setEnabled(false);
                                    getOnBackPressedDispatcher().onBackPressed();
                                }
                            }
                        });
            }
        });
    }
}
''')
# 8. file provider used only to share images from the app cache
jd=os.path.dirname(ma)
open(os.path.join(jd,'WirdFileProvider.java'),'w',encoding='utf-8').write('''package app.wird.adhkar;

import androidx.core.content.FileProvider;

public class WirdFileProvider extends FileProvider {
}
''')
os.makedirs(res+'/xml',exist_ok=True)
open(res+'/xml/wird_share_paths.xml','w',encoding='utf-8').write('<?xml version="1.0" encoding="utf-8"?>\n<paths>\n    <cache-path name="share" path="share/" />\n</paths>\n')
m=open(mf,encoding='utf-8').read()
prov='''    <provider
        android:name="app.wird.adhkar.WirdFileProvider"
        android:authorities="${applicationId}.wirdshare"
        android:exported="false"
        android:grantUriPermissions="true">
        <meta-data
            android:name="android.support.FILE_PROVIDER_PATHS"
            android:resource="@xml/wird_share_paths" />
    </provider>
'''
assert m.count('</application>')==1
if 'WirdFileProvider' not in m: m=m.replace('</application>',prov+'</application>')
open(mf,'w',encoding='utf-8').write(m)
print('patched; versionCode',run,'minSdk 24 target 36')
